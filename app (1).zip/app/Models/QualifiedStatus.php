<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QualifiedStatus extends Model
{
    use HasFactory;
    protected $guarded = [];
}
