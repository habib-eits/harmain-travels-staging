  <div class="footer">
    Developed By - <strong>XTBook Travel Pro</strong><br>
    For more info visit <a href="https://www.xtbooks.app" target="_blank">www.xtbooks.app</a>
  </div>