<table class="table table-striped  table-sm table-bordered" id="transport-table" style="width: 100%;">

    <thead>
      
             
            <th>Date</th>
            <th>City</th>
             <th>Sector</th>
             <th>Vehicle</th>
             <th>Vehicle Type</th>
             <th>Quantity</th>
             <th>Total Pax</th>
             <th>Purchase</th>
             <th>Sale</th>
             <th>Action</th>
            {{-- <th style="display: none;">Status</th> --}}
            {{-- <th style="display: none;">Purchase</th> --}}
            {{-- <th style="display: none;">Sale</th> --}}
            {{-- <th style="display: normal">Quantity</th> --}}
            {{-- <th style="display: none;">Destination</th> --}}
            {{-- <th style="display: none;">Flight</th> --}}
            {{-- <th style="display: none;">Brn</th> --}}
            {{-- <th style="display: none;">TourAgentName</th> --}}
  
    
    </thead>

 
</table>
