<table class="table table-sm table-bordered" id="hotel-table" style="width: 100%;">

<thead>
<th></th>

<th>City</th>
<th >Check In</th>
<th >Check Out</th>
<th>Nights</th>
<th>Hotel Name</th>
<th>Room Type</th>
<th>RoomStatus</th>
<th>Room/Bed</th>
<th>Pax</th>
<th>Payable</th>
<th>Receivable</th>


</thead>

 
</table>
 