<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                Copyright &copy {{date('Y')}} Smart ERP App . All rights reserved
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    <!-- Design &amp; Develop by IT Department, INU -->
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>