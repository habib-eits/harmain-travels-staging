<table class="table table-striped  table-sm table-bordered" id="transport-table" style="width: 100%;">

    <thead>
      
             
            <th>Date</th>
            <th>City</th>
             <th>Vehicle</th>
            <th style="display: none;">Status</th>
            <th>Quantity</th>
            <th>Pax</th>
            <th style="display: none;">Purchase</th>
            <th style="display: none;">Sale</th>
            <th style="display: normal">Payable</th>
            <th>Receivable</th>
            <th nowrap="">Pickup From</th>
            <th style="display: none;">Destination</th>
            <th>Time</th>
            <th style="display: none;">Flight</th>
            <th style="display: none;">Brn</th>
            <th style="display: none;">TourAgentName</th>
  
    
    </thead>

 
</table>
